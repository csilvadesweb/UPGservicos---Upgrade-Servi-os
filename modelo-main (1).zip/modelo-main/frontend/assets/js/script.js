
document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript carregado!");
});

function finalizarCompra() {
    alert("Compra finalizada com sucesso!");
}
